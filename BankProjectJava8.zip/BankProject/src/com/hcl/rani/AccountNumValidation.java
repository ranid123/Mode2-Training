package com.hcl.rani;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class AccountNumValidation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scannerObj = new Scanner(System.in);
		List<Integer> list = new ArrayList<Integer>();
		System.out.println("Enter size of List");
		int n = scannerObj.nextInt();
		int Totalaccount;

		System.out.println("Enter 5 digit numbers");
		for (int i = 0; i < n; i++) {
			Totalaccount = scannerObj.nextInt();
			list.add(Totalaccount);

		}
		List<String> list2 = list.stream().map(str -> "SBI" + str).collect(Collectors.toList());

		list2.stream().filter(str -> (str.length() == 8)).limit(10).forEach(System.out::println);
		List<Customer> custList = Arrays.asList(new Customer("Rani", 22, "1234567890", 1000000),
				new Customer("Manasa", 21, "1234525890", 200000), new Customer("sushma", 25, "1234567890", 3000000),
				new Customer("Anu", 22, "1233567890", 400000), new Customer("Sharath", 20, "1234467890444", 900000),
				new Customer("Manu", 22, "1234567890", 600000), new Customer("Manvi", 17, "1234567890", 400000),
				new Customer("Bindu", 19, "1234567890", 300000));

		System.out.println("Phone validation");

		List<Customer> customerList1 = custList.stream().filter(i -> ((i.phone).length() == 10))
				.collect(Collectors.toList());
		System.out.println("Age validation");
		customerList1 = customerList1.stream().filter(i -> (i.age) > 18).collect(Collectors.toList());

		customerList1 = customerList1.stream().filter(i -> Character.isUpperCase((i.name).charAt(0)))
				.collect(Collectors.toList());

		accLink(customerList1, list2);
		displayCust(customerList1);
		System.out.println("After Sorting ");

		customerList1 = customerList1.stream().sorted((s1, s2) -> s1.getName().compareTo(s2.getName()))
				.collect(Collectors.toList());
		displayCust(customerList1);
		System.out.println("Enter your account number");
		String nll = scannerObj.nextLine();
		String accNo = scannerObj.nextLine();

		String option = null;
		do {
			System.out.println("Enter your option");
			System.out.println("1.Withdraw\t2.Deposit\t3.Withdraw List Display\t4.Exit");
			option = scannerObj.nextLine();
			for (int i = 0; i < customerList1.size(); i++) {
				if (accNo.equals(customerList1.get(i).accNum)) {
					switch (option) {
					case "1":
						BankOperations b = new BankOperations();
						System.out.println("Enter the amount");
						double amount = scannerObj.nextDouble();
						b.withdraw(customerList1.get(i), amount);
						break;

					case "2":
						BankOperations b1 = new BankOperations();
						System.out.println("Enter the amount");
						amount = scannerObj.nextDouble();
						b1.deposit(customerList1.get(i), amount);
						break;
					case "3":
						BankOperations b2 = new BankOperations();
						b2.display(customerList1.get(i));
						break;
					case "4":
						break;
					}
				}
			}
		} while (!option.equals("4"));

	}

	public static void accLink(List<Customer> customerList1, List<String> list2) {
		for (int i = 0; i < customerList1.size(); i++) {
			customerList1.get(i).accNum = list2.get(i);
		}
	}

	public static void displayCust(List<Customer> customerList1) {
		for (int i = 0; i < customerList1.size(); i++) {
			System.out.println(customerList1.get(i).name + " " + customerList1.get(i).age + " " + customerList1.get(i).phone + " "
					+ customerList1.get(i).accNum + "\n");
		}
	}

}

package com.hcl.rani;

import java.util.ArrayList;
import java.util.List;

public class Customer {
	String name;
	int age;
	String phone;
	String accNum;
	double balance;
	List<Double> withdrawList = new ArrayList<Double>();

	public Customer(String name, int age, String phone, double balance) {
		super();
		this.name = name;
		this.age = age;
		this.phone = phone;
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAccNum() {
		return accNum;
	}

	public void setAccNum(String accNum) {
		this.accNum = accNum;
	}

}

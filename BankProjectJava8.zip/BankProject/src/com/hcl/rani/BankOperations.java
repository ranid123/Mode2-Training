package com.hcl.rani;

import java.util.Scanner;

public class BankOperations {
	Scanner s = new Scanner(System.in);

	// method to perform withdraw operation
	public void withdraw(Customer cust, double amt) {
		if (cust.balance > amt) {
			cust.balance = cust.balance - amt;
			cust.withdrawList.add(amt);
			System.out.println("Amount withdrawn is " + amt);
			System.out.println("Available amount is " + cust.balance);
		} else {
			System.out.println("Available amount is not sufficient to withdraw please deposit..");
		}
	}

	// method to perform deposit operation
	public void deposit(Customer cust, double amt) {
		cust.balance = cust.balance + amt;
		System.out.println("Amount deposited is " + amt);
		System.out.println("Available amount is " + cust.balance);
	}

	// method to display last 10 withdraws
	public void display(Customer cust) {
		int flag = 0;
		System.out.println("Last 10 withdraws are");
		for (int i = cust.withdrawList.size() - 1; i >= 0; i--) {
			if (flag == 10) {
				break;
			} else {
				System.out.println(cust.withdrawList.get(i));
			}
		}
	}
}

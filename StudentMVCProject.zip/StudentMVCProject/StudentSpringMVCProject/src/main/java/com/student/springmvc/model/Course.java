package com.student.springmvc.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="course")
public class Course {
	
	@Id
	private CourseId courseId;

	public CourseId getCourseId() {
		return courseId;
	}

	public void setCourseId(CourseId courseId) {
		this.courseId = courseId;
	}
	
	

}

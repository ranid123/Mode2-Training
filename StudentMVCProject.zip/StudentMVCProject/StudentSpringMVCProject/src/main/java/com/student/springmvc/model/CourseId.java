package com.student.springmvc.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CourseId implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String collegeCode;
	
	private String course;
	
	

	public CourseId(String collegeCode, String course) {
		super();
		this.collegeCode = collegeCode;
		this.course = course;
	}

	public String getCollegeCode() {
		return collegeCode;
	}

	public void setCollegeCode(String collegeCode) {
		this.collegeCode = collegeCode;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}
		
}

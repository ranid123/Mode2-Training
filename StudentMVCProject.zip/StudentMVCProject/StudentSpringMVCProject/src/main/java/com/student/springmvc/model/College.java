package com.student.springmvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="college")
public class College {

		@Id
		@Column(name="collegeCode")
		private String collegeCode;
		
		@Column(name="collegeName")
		private String collegeName;
		
		@Column(name="place")
		private String place;

		public String getCollegeCode() {
			return collegeCode;
		}

		public void setCollegeCode(String collegeCode) {
			this.collegeCode = collegeCode;
		}

		public String getCollegeName() {
			return collegeName;
		}

		public void setCollegeName(String collegeName) {
			this.collegeName = collegeName;
		}

		public String getPlace() {
			return place;
		}

		public void setPlace(String place) {
			this.place = place;
		}
		
		
		
}

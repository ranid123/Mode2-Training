package com.student.springmvc;

import java.io.IOException;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.student.springmvc.dto.StudentDto;
import com.student.springmvc.model.Academic;
import com.student.springmvc.model.Student;
import com.student.springmvc.service.StudentService;

@Controller
public class StudentController {

	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);

	@Autowired
	private StudentService studentService;

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}

	@RequestMapping(value = "/student1/addStudent", method = RequestMethod.GET)
	public String saveStudentDetails(Model model) {
		logger.info("Returning student_details.jsp page");

		model.addAttribute("student1", new StudentDto());
		return "student_details";
	}

	@RequestMapping(value = "/student1/addStudent.do", method = RequestMethod.POST)
	public String saveStudentDetailsAction(@ModelAttribute("student1") StudentDto studentdto, Model model) {
		logger.info("Returning student_success.jsp page");
		ModelMapper mapper = new ModelMapper();
		Student student = mapper.map(studentdto, Student.class);
		Academic academic = mapper.map(studentdto, Academic.class);

		model.addAttribute("student1", studentdto);
		this.studentService.addStudentDetails(student, academic);
		return "student_success";
	}

	@RequestMapping(value = "/studentUSN/getPlace", method = RequestMethod.GET)
	public String getStudentClgPlace(Model model) {
		logger.info("Returning studentClgPlace.jsp page");

		model.addAttribute("studentUSN", new StudentDto());
		// model.addAttribute("student", new Academic());
		return "studentClgPlace";
	}

	@RequestMapping(value = "/studentUSN/getPlace.do", method = RequestMethod.GET)
	public String getStudentClgPlaceAction(@ModelAttribute("studentUSN") StudentDto studentdto, Model model) {
		logger.info("Returning collegePlace.jsp page");
		ModelMapper mapper = new ModelMapper();
		Student student = mapper.map(studentdto, Student.class);
		String usn = student.getUsn();
		System.out.println("USN= " + usn);
		model.addAttribute("usn", usn);
		model.addAttribute("place", this.studentService.getStudentCollegePlace(usn));
		return "collegePlace";
	}

	@RequestMapping(value = "/getStudent/{pageNo}")
	public String getStudentDetails(@PathVariable int pageNo, Model model) throws IOException {

		int pageSize = 3;
		if (pageNo!= 1) {
			pageNo = (pageNo - 1) * pageSize + 1;
		} 
		System.out.println(pageNo);
		List<Student> listStudent = studentService.getStudentDetails(pageNo, pageSize);
		model.addAttribute("listStudent", listStudent);
		return "allStudentDetails";
	}

	@RequestMapping(value = "/searchPlace/{usn}", method = RequestMethod.GET)
	@ResponseBody
	public String search(@PathVariable String usn) {
		return studentService.getStudentCollegePlace(usn);
	}

	@RequestMapping(value = "/getStudent", method = RequestMethod.GET)
	@ResponseBody
	public List<Student> getStudent() {
		return studentService.getStudent();
	}

	@RequestMapping(value = "/get/studentper", method = RequestMethod.GET)
	@ResponseBody
	public List<Student> getStudentByPercentage() {
		return studentService.getStudentByPercentage();
	}

	@RequestMapping(value = "/get/studentage", method = RequestMethod.GET)
	@ResponseBody
	public List<Student> getStudentByAge() {
		return studentService.getStudentByAge();
	}
}

package com.student.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.student.springmvc.dao.StudentDAO;
import com.student.springmvc.model.Academic;
import com.student.springmvc.model.Student;

@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDAO studentDao;


	public void setStudentDao(StudentDAO studentDao) {
		this.studentDao = studentDao;
	}


	//add student details to Student and Academic tables 
	@Transactional
	@Override
	public void addStudentDetails(Student student, Academic academic) {
		// TODO Auto-generated method stub
		studentDao.addStudentDetails(student, academic);
	}

	//to get place of college using usn of the student 
	@Transactional
	@Override
	public String getStudentCollegePlace(String usn) {
		// TODO Auto-generated method stub
		return studentDao.getStudentCollegePlace(usn);
	}

	//to get all student details using pagination
	@Transactional
	@Override
	public List<Student> getStudentDetails(int pageNo, int total) {
		// TODO Auto-generated method stub
		return studentDao.getStudentDetails(pageNo, total);
	}

	//get all students using Criteria 
	@Transactional
	@Override
	public List<Student> getStudent() {
		// TODO Auto-generated method stub
		return studentDao.getStudent();
	}

	//get all students by their percentage
	@Transactional
	@Override
	public List<Student> getStudentByPercentage() {
		// TODO Auto-generated method stub
		return studentDao.getStudentByPercentage();
	}

	//get all students by their age
	@Transactional
	@Override
	public List<Student> getStudentByAge() {
		// TODO Auto-generated method stub
		return studentDao.getStudentByAge();
	}	

}

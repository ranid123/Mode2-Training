package com.student.springmvc.dao;

import java.util.List;

import com.student.springmvc.model.Academic;
import com.student.springmvc.model.Student;

public interface StudentDAO {
	
	public void addStudentDetails(Student student,Academic academic);
	
	public String getStudentCollegePlace(String usn);
	
	public List<Student> getStudentDetails(int pageNo,int total);
	
	public List<Student> getStudent();
	
	public List<Student> getStudentByPercentage();
	
	public List<Student> getStudentByAge();
}

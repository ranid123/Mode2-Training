package com.student.springmvc.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.student.springmvc.exception.CollegeCodeNotFoundException;
import com.student.springmvc.model.Academic;
import com.student.springmvc.model.College;
import com.student.springmvc.model.Student;

@Repository
public class StudentDAOImpl implements StudentDAO {

	private static final Logger logger = LoggerFactory.getLogger(StudentDAOImpl.class);

	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionfactory) {
		this.sessionFactory = sessionfactory;
	}

	@Override
	public void addStudentDetails(Student student, Academic academic) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(student);
		session.persist(academic);
		logger.info("Student details saved successfully, Student Details=" + student);
		logger.info("Student Academic details saved successfully, Student Academic Details=" + academic);
	}

	@Override
	public String getStudentCollegePlace(String usn) {
		
		StringBuffer studentUSN = new StringBuffer(usn);
		String place = null;
		String clgCode = studentUSN.substring(1, 3);

		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("from College where collegeCode= :collegeCode");
		query.setParameter("collegeCode", clgCode);
		List list = query.list();
		if (list == null) {
			throw new CollegeCodeNotFoundException("College Code is Not Found");
		} else {
			Iterator iterator1 = list.iterator();
			while (iterator1.hasNext()) {
				College clgObj = (College) iterator1.next();
				place = clgObj.getPlace();
				logger.info("Student College Place=" + place);
			}
			return "The place of student college is " + place;
		}

	}

	@Override
	public List<Student> getStudentDetails(int pageNo, int pageSize) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			Query query = session.createQuery("from Student");
			query.setFirstResult(pageNo - 1);
			query.setMaxResults(pageSize);

			List<Student> students = query.list();
			logger.info("All Student details are fetched");
			return students;
		} catch (HibernateException e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		return null;
	}

	@Override
	public List<Student> getStudent() {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Student.class);
		List<Student> list = criteria.list();
		logger.info("All Student details are fetched using Criteria");
		return list;

	}

	public List<College> getCollege() {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			Query query = session.createQuery("from College");
			List<College> colleges = query.list();
			logger.info("All Student details are fetched using Criteria");
			return colleges;
		} catch (HibernateException e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		return null;

	}

	@Override
	public List<Student> getStudentByPercentage() {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.gt("percentage", 80.0));
		List list1 = criteria.list();
		logger.info("All Student details based on percentage are fetched using Criteria");
		return list1;
	}

	@Override
	public List<Student> getStudentByAge() {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.lt("age", 20));
		List list2 = criteria.list();
		logger.info("All Student details based on age are fetched using Criteria");
		return list2;
	}
}